from tkinter import *
import math
###############################################
#Multiplayer Server Message Handling (All adapted from Rohans examples)
###############################################
# import socket
# import threading
# from queue import Queue

# HOST = "128.237.180.202"
# PORT = 50003

# server = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 

# server.connect((HOST,PORT))
# print("connected to server")

# def handleServerMsg(server, serverMsg): #handles msgs from server
# 	server.setblocking(1)
# 	msg = ""
# 	command = ""
# 	while True:
# 		msg += server.recv(10).decode("UTF-8")
# 		command = msg.split("\n")
# 		while (len(command) > 1):
# 			readyMsg = command[0]
# 			print(readyMsg)
# 			msg = "\n".join(command[1:])
# 			serverMsg.put(readyMsg)
# 			command = msg.split("\n")

# serverMsg = Queue(100)
# threading.Thread(target = handleServerMsg, args = (server, serverMsg)).start()
###############################################
## Objects
###############################################
class Tank(object):
	def __init__(self, x, y, sizeX, sizeY, color1, color2, angle, rotSpeed, moveSpeed,canvasWidth, canvasHeight):
		self.x = x
		self.y = y
		self.sizeX = sizeX
		self.sizeY = sizeY
		self.treadSizeY = 0.15*self.sizeY
		self.treadSizeX = 0.1*self.sizeX
		self.nozzleSizeY = 0.2*self.sizeY
		self.nozzleSizeX = 0.25*self.sizeX
		self.diag = ((self.sizeX/2)**2+(self.sizeY/2)**2)**.5
		self.tankColor = color1
		self.nozzleColor = color2
		self.canvasHeight = canvasHeight
		self.rotSpeed = rotSpeed
		self.moveSpeed = moveSpeed
		self.canvasWidth = canvasWidth
		self.angle = angle #degree val for angle
		self.theta = (self.angle*math.pi)/180 #rad val for angle
	def draw(self, canvas):
		theta = self.theta #temp var for theta
		tankVerts = []
		theta += math.atan2(self.sizeY,self.sizeX) #calc theta for 1st point
		tankVerts.append(self.x+self.diag*math.cos(theta)) #vert1x
		tankVerts.append(self.y-self.diag*math.sin(theta)) #vert1y
		theta+=2*(math.atan2(self.sizeX,self.sizeY))#add to theta for 2nd point
		tankVerts.append(self.x+self.diag*math.cos(theta))  #vert2x
		tankVerts.append(self.y-self.diag*math.sin(theta)) #vert2y
		theta+=2*(math.atan2(self.sizeY,self.sizeX))#add to theta for 3rd point
		tankVerts.append(self.x+self.diag*math.cos(theta))  #vert3x
		tankVerts.append(self.y-self.diag*math.sin(theta)) #vert3y
		theta+=2*(math.atan2(self.sizeX,self.sizeY))#add to theta for 4th point
		tankVerts.append(self.x+self.diag*math.cos(theta))  #vert4x
		tankVerts.append(self.y-self.diag*math.sin(theta))  #vert4y
		# treadVerts = []
		# treadDiag = (self.treadSizeX**2+self.treadSizeY**2)**.5
		# treadVerts.append(self.x+(self.diag+treadDiag)*math.cos(theta))
		# treadVerts.append(self.y-(self.diag+treadDiag)*math.sin(theta))

		# canvas.create_rectangle(tankVerts[2]-self.treadSizeX,
		# 						tankVerts[3]-self.treadSizeY,
		# 						tankVerts[0]+self.treadSizeX,
		# 						tankVerts[1]+self.treadSizeY,
		# 						fill = "black") #Tank Left Treads
		# canvas.create_rectangle(tankVerts[4]-self.treadSizeX,
		# 						tankVerts[5]-self.treadSizeY,
		# 						tankVerts[6]+self.treadSizeX,
		# 						tankVerts[7]+self.treadSizeY,
		# 						fill = "black") #Tank Right Treads
		canvas.create_polygon(tankVerts[0],tankVerts[1],tankVerts[2],tankVerts[3],
							  tankVerts[4],tankVerts[5],tankVerts[6],tankVerts[7],
							  fill = self.tankColor) #draw body of tank
		cx,cy = (tankVerts[0]+tankVerts[6])//2, (tankVerts[1]+tankVerts[7])//2 #avg of 1,4 tankVerts
		r = 10 #random test magic val
		canvas.create_oval(cx-r,cy-r,cx+r,cy+r, fill = self.nozzleColor) #temp nozzle
	def rotateLeft(self):
		self.angle += self.rotSpeed
		self.theta = (self.angle*math.pi)/180
	def rotateRight(self):
		self.angle -= self.rotSpeed
		self.theta = (self.angle*math.pi)/180
	def moveForward(self):
		self.x+=self.moveSpeed*math.cos(self.theta)
		self.y-=self.moveSpeed*math.sin(self.theta)
	def moveBackward(self):
		self.x-=self.moveSpeed*math.cos(self.theta)
		self.y+=self.moveSpeed*math.sin(self.theta)
	def shoot(self,data):
		bullet = Bullet(self.x,self.y,self.nozzleColor,10,3,self.angle,
						self.canvasHeight,self.canvasWidth)
		data.bullets.append(bullet)

class Bullet(object):
	def __init__(self,x,y,color,radius,speed,angle,canvasHeight,canvasWidth):
		self.x = x
		self.y = y
		self.color = color
		self.radius = radius
		self.speed = speed
		self.angle = angle
		self.theta = (self.angle*math.pi)/180 #rad val for angle
		self.canvasHeight = canvasHeight
		self.canvasWidth = canvasWidth
		self.bounces = 0
	def draw(self,canvas):
		x0,y0 = self.x-self.radius, self.y-self.radius
		x1,y1 = self.x+self.radius, self.y+self.radius
		canvas.create_oval(x0,y0,x1,y1,fill=self.color)

	def move(self):
		self.x+=self.speed*math.cos(self.theta)
		self.y-=self.speed*math.sin(self.theta)
	def borderCollision(self):
		if (self.x+self.radius>=self.canvasWidth or self.x-self.radius<=0):
			self.theta = math.pi - self.theta
			self.bounces +=1
		if (self.y-self.radius<=0 or self.y+self.radius>=self.canvasHeight):
			self.theta = 2*math.pi - self.theta
			self.bounces+=1
	def killBullet(self):
		if self.bounces>=5:
			return True

################################################
##	Model
################################################
def init(data):
	data.x, data.y = data.width//2, data.height//2
	data.moveSpeed = 5
	data.rotateSpeed = 5
	data.tankSizeX,data.tankSizeY = 100,80
	data.angle = 0
	data.tank = Tank(data.x,data.y,data.tankSizeX,data.tankSizeY,"green","red",
						data.angle,data.rotateSpeed,data.moveSpeed,
						data.width, data.height)
	data.bullets = []
	data.gameOver = False
################################################
## Control
################################################
def keyPressed(event, data):
    if (event.keysym == "Left"):
        data.tank.rotateLeft()
    if (event.keysym == "Right"):
        data.tank.rotateRight()
    if (event.keysym == "Up"):
    	data.tank.moveForward()
    if (event.keysym == "Down"):
    	data.tank.moveBackward()
    if (event.keysym == "space"):
    	data.tank.shoot(data)

def mousePressed(event, data):
    pass
def timerFired(data):
    for bullet in data.bullets:
    	bullet.move()
    	bullet.borderCollision()
    	if bullet.killBullet()lo:
    		data.bullets.remove(bullet)

################################################
## View
################################################
def drawBorder(canvas, data):
	canvas.create_rectangle(5,5,data.width,data.height,width=2)

def redrawAll(canvas, data):
    if (not data.gameOver):
    	drawBorder(canvas,data)
    	data.tank.draw(canvas)
    	for bullet in data.bullets:
    		bullet.draw(canvas)

##################################################
##Run Function (adapted from course notes)
##################################################
def run(width=300, height=300):
    def redrawAllWrapper(canvas, data):
        canvas.delete(ALL)
        redrawAll(canvas, data)
        canvas.update()    

    def mousePressedWrapper(event, canvas, data):
        mousePressed(event, data)
        redrawAllWrapper(canvas, data)

    def keyPressedWrapper(event, canvas, data):
        keyPressed(event, data)
        redrawAllWrapper(canvas, data)

    def timerFiredWrapper(canvas, data):
        timerFired(data)
        redrawAllWrapper(canvas, data)
        canvas.after(data.timerDelay, timerFiredWrapper, canvas, data)
    
    # Set up data and call init
    class Struct(object): pass
    data = Struct()
    data.width = width
    data.height = height
    data.timerDelay = 10 # milliseconds
    init(data)
    # create the root and the canvas
    root = Tk()
    canvas = Canvas(root, width=data.width, height=data.height)
    canvas.pack()
    # set up events
    root.bind("<Button-1>", lambda event:
                            mousePressedWrapper(event, canvas, data))
    root.bind("<Key>", lambda event:
                            keyPressedWrapper(event, canvas, data))
    timerFiredWrapper(canvas, data)
    # and launch the app
    root.mainloop()  # blocks until window is closed
    print("bye!")

run(800, 800)